//контекст функции
function foo(){
    var bar = "bar2";
    console.log(this.bar);
}
 
var bar = "bar1";
 
foo();

//контекст объекта
const o = {
    bar: "bar3",
    foo: function(){
        console.log(this.bar);
    }
}
const bar = "bar1";
o.foo();

//пример на понимание
var o1 = {
    bar: "bar1", // св-во
    foo: function(){ //метод
        console.log(this.bar);
    }
}

var o2 = {
    bar: "bar2",
    foo: o1.foo // метод
};

var bar = "bar3";
var foo = o1.foo;

o1.foo();
o2.foo();
foo();

//явная привязка конекста
var bar = "bar2";
 
function daz(){
    var bar = "bar5";
    function maz(){
        console.log(this);
        console.log(this.bar);
    }
    maz();
}
daz();

function foo(){
    console.log(this.bar);
}
 
var o3 = {bar: "bar3"}
var bar = "bar1";
foo();
foo.apply(o3);
foo.call(o3);
 
var o4 = {bar: "bar4"}
var func = foo.bind(o4);
func();