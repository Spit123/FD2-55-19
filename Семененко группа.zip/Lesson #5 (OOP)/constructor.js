// конструктор типа Car
function Car(_name, _year){
  const self = this;

  this.name = _name;
  this.year = _year;

  const wheels = 4;
  const maxSpeed = 160;

  function getAutoName() {
    return (`Модель авто: ${self.name}`);
  }

  function getMaxSpeed() {
    return (maxSpeed + " km/h");
  }

  this.getCarInfo = function(){
    console.log(`${getAutoName()}
Год выпуска: ${this.year}
Колес: ${wheels}
Макс. скорость: ${getMaxSpeed()}`);
  };
};

// конструктор типа Driver
function Driver(_name, _age) {
  this.name = _name;
  this.age = _age;
  this.driveCar = function(car){
    //console.log(car);
    console.log(`${this.name} ведет машину ${car.name} ${car.year} года выпуска`);
  };
  this.displayInfo = function(){
    console.log(`Водитель: ${this.name}; возраст: ${this.age}`);
  };
};

const Vasya = new Driver("Василий", 31);
const Tolya = new Driver("Анатолий", 35);

Vasya.displayInfo();
Tolya.displayInfo();

const audi = new Car("Audi A6", 2010);
const bmw = new Car("BMW X5", 2012);

audi.getCarInfo();
bmw.getCarInfo();

Tolya.driveCar(bmw);